<?php 

	/**
	* Conexion a bbdd usando mysqli
	*/
	class Connect 
	{
		public static function connection(){
			$cnx = new mysqli('localhost:3306', 'nascor01', 'Nascor2020!', 'CursoPHP');
			$cnx->set_charset("utf8");
			return $cnx;
		}
	}
?>