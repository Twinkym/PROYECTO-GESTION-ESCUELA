<?php
$id_alumno=$_POST ['id_alumno'];
$id_curso=$_POST ['id_curso'];
$nota=$_POST ['nota'];
require_once("../config/db.php");
require_once('../models/alumnos_model.php');
$user = new alumnos_model();
$datosalumno = $user->set_alumno_curso_nota($id_alumno, $id_curso,$nota);

if ($datosalumno) {
	require_once('../models/cursos_model.php');
	$asignatura = new asignaturas_model();
	$nombre_curso=$asignatura->get_asignatura($id_curso);
	$data = $user->get_alumnos_curso($id_curso);
	
	require_once ('../models/conexion_model.php');
	$con = new conexion();
	$identificado = $con->identificado();
	require('../views/alumnos_curso_vista.php');
}
else {
	echo 'Error';
}
?>