<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" href="estilos.css">
	</head>
	<body>
		<form method="post" action="../controllers/validar_controller.php" name="signin-form">
    		<div class="form-element">
        		<label>Username</label>
        		<input type="text" name="username"  required />
    		</div>
    		<div class="form-element">
        		<label>Password</label>
        		<input type="password" name="password" required />
    		</div>
    		<button type="submit" name="login" value="login">Log In</button>
		</form>		
	</body>
</html>