<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8" />
        <title>Lista de Usuarios curso</title>
    </head>
    <body>
		<h1>Lista de alumnos del curso <?php echo $nombre_curso['Nombre']; ?> </h1>
        <table>
			<thead>
                <tr>
                    <th>Nombre</th>
                    <th>Apellido 1</th>
                    <th>Apellido 2</th>
                    <th>Fecha Nacimiento</th>
					<?php
					if ($identificado=='ok') { ?>
					<th>Nota</th>
					<?php } ?>
                </tr>
            </thead>
            <tbody>
				<?php foreach ($data as $user) { ?>
                <tr>
                    <td><?php echo $user['Nombre']; ?></td>
                    <td><?php echo $user['Apellido1']; ?></td>
                    <td><?php echo $user['Apellido2']; ?></td>
                    <td><?php echo $user['Fecha_nac']; ?></td>
					<?php if ($identificado=='ok') { ?>	
					<td>
						<form action="../controllers/Nota_Controller.php" method="post">
						<input type="hidden" value="<?php echo $user ['id']?>" name="id.alumno">
						<input type="hidden" value="<?php echo $id_curso?>" name="id.curso">
						<input type="text" value="<?php echo $user ['nota']?>" name="nota" size=3>
						<input type="submit" value="Guardar">
						</form>
					</td>
					<?php } ?>
                </tr>
                <?php } ?>
			</tbody>
        </table>
    </body>
</html>