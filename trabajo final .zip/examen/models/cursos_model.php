<?php
/**
* clase Asisnaturas
*/
class asignaturas_model extends Connect
{
	private $db;
	private $asignaturas;
	public function __construct(){
		$this->db = Connect::connection();
		$this->asignaturas = array();
	}
	public function get_asignaturas(){
		$query = $this->db->query("SELECT * FROM Asignaturas");
		while ($rows = $query->fetch_assoc()){
			$this->asignaturas[] = $rows;
		}
		return $this->asignaturas;
	}
	
	public function get_asignatura($id_curso) {
		$sql="SELECT * FROM Asignaturas WHERE Asignaturas.id=".$id_curso;
		$query = $this->db->query($sql);
		$row = $query->fetch_assoc();
		return $row;
	}	
	
}	

?>